

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* ============================================================
   DEFINICOES E ESTRUTURAS
   ============================================================ */

#define MAX_ESTUDANTES 100
#define MAX_NOME       100
#define FICHEIRO_TXT   "estudantes.txt"
#define FICHEIRO_BIN   "estudantes.bin"
#define SAIDA_TXT      "saida.txt"

/* Estrutura que representa um estudante */
typedef struct {
    int   matricula;
    char  nome[MAX_NOME];
    float nota;
} Estudante;

/* Array global de estudantes e contador */
Estudante lista[MAX_ESTUDANTES];
int totalEstudantes = 0;
int listaOrdenada   = 0; /* flag: 1 se estiver ordenada por matricula */

/* ============================================================
   PROTOTIPOS DAS FUNCOES
   ============================================================ */

/* --- Ficheiros --- */
void lerFicheiroTexto(void);
void gravarFicheiroTexto(void);
void gravarFicheiroBinario(void);
void lerFicheiroBinario(void);

/* --- Exibicao --- */
void exibirLista(void);
void exibirEstudante(Estudante e);

/* --- Ordenacao --- */
void bubbleSortMatricula(void);
void selectionSortNome(void);
void insertionSortNota(void);
void menuOrdenacao(void);

/* --- Pesquisa --- */
int  pesquisaLinearMatricula(int matricula);
int  pesquisaBinariaMatricula(int matricula);
int  pesquisaLinearNome(char *nome);
void menuPesquisa(void);

/* --- Menu --- */
void menuPrincipal(void);


/* ============================================================
   FUNCOES DE EXIBICAO
   ============================================================ */

void exibirEstudante(Estudante e) {
    printf("  Matricula: %d | Nome: %-30s | Nota: %.2f\n",
           e.matricula, e.nome, e.nota);
}

void exibirLista(void) {
    int i;
    if (totalEstudantes == 0) {
        printf("\n  [!] Nenhum estudante carregado em memoria.\n");
        return;
    }
    printf("\n  %-10s %-30s %-6s\n", "Matricula", "Nome", "Nota");
    printf("  %-10s %-30s %-6s\n",
           "----------", "------------------------------", "------");
    for (i = 0; i < totalEstudantes; i++) {
        printf("  %-10d %-30s %.2f\n",
               lista[i].matricula, lista[i].nome, lista[i].nota);
    }
    printf("  Total: %d estudante(s).\n", totalEstudantes);
}


/* ============================================================
   FUNCOES DE FICHEIROS
   ============================================================ */

/*
 * Ler dados do ficheiro de texto "estudantes.txt"
 * Formato de cada linha: matricula nome nota
 * Exemplo: 1001 Joao_Silva 15.5
 */
void lerFicheiroTexto(void) {
    FILE *fp;
    Estudante temp;

    fp = fopen(FICHEIRO_TXT, "r");
    if (fp == NULL) {
        printf("\n  [ERRO] Nao foi possivel abrir '%s'.\n", FICHEIRO_TXT);
        printf("         Verifique se o ficheiro existe na mesma pasta do programa.\n");
        return;
    }

    totalEstudantes = 0;
    listaOrdenada   = 0;

    while (fscanf(fp, "%d %s %f",
                  &temp.matricula, temp.nome, &temp.nota) == 3) {
        if (totalEstudantes >= MAX_ESTUDANTES) {
            printf("\n  [AVISO] Limite de %d estudantes atingido.\n", MAX_ESTUDANTES);
            break;
        }
        lista[totalEstudantes] = temp;
        totalEstudantes++;
    }

    fclose(fp);
    printf("\n  [OK] %d estudante(s) carregado(s) de '%s'.\n",
           totalEstudantes, FICHEIRO_TXT);
}

/*
 * Gravar dados no ficheiro de texto "saida.txt"
 */
void gravarFicheiroTexto(void) {
    FILE *fp;
    int i;

    if (totalEstudantes == 0) {
        printf("\n  [!] Nenhum dado para gravar. Carregue os dados primeiro.\n");
        return;
    }

    fp = fopen(SAIDA_TXT, "w");
    if (fp == NULL) {
        printf("\n  [ERRO] Nao foi possivel criar '%s'.\n", SAIDA_TXT);
        return;
    }

    for (i = 0; i < totalEstudantes; i++) {
        fprintf(fp, "%d %s %.2f\n",
                lista[i].matricula, lista[i].nome, lista[i].nota);
    }

    fclose(fp);
    printf("\n  [OK] %d estudante(s) gravado(s) em '%s'.\n",
           totalEstudantes, SAIDA_TXT);
}

/*
 * Gravar dados num ficheiro binario "estudantes.bin"
 */
void gravarFicheiroBinario(void) {
    FILE *fp;

    if (totalEstudantes == 0) {
        printf("\n  [!] Nenhum dado para gravar. Carregue os dados primeiro.\n");
        return;
    }

    fp = fopen(FICHEIRO_BIN, "wb");
    if (fp == NULL) {
        printf("\n  [ERRO] Nao foi possivel criar '%s'.\n", FICHEIRO_BIN);
        return;
    }

    fwrite(&totalEstudantes, sizeof(int), 1, fp);
    fwrite(lista, sizeof(Estudante), totalEstudantes, fp);

    fclose(fp);
    printf("\n  [OK] %d estudante(s) gravado(s) no ficheiro binario '%s'.\n",
           totalEstudantes, FICHEIRO_BIN);
}

/*
 * Ler dados de um ficheiro binario "estudantes.bin"
 */
void lerFicheiroBinario(void) {
    FILE *fp;
    int lidos;

    fp = fopen(FICHEIRO_BIN, "rb");
    if (fp == NULL) {
        printf("\n  [ERRO] Nao foi possivel abrir '%s'.\n", FICHEIRO_BIN);
        return;
    }

    fread(&lidos, sizeof(int), 1, fp);
    if (lidos > MAX_ESTUDANTES) lidos = MAX_ESTUDANTES;

    fread(lista, sizeof(Estudante), lidos, fp);
    totalEstudantes = lidos;
    listaOrdenada   = 0;

    fclose(fp);
    printf("\n  [OK] %d estudante(s) carregado(s) do ficheiro binario '%s'.\n",
           totalEstudantes, FICHEIRO_BIN);
}


/* ============================================================
   ALGORITMOS DE ORDENACAO
   ============================================================ */

/*
 * BUBBLE SORT — Ordena por Numero de Matricula (crescente)
 * Complexidade: O(n^2)
 * Ideia: compara pares adjacentes e troca-os se estiverem fora de ordem.
 */
void bubbleSortMatricula(void) {
    int i, j;
    Estudante temp;

    for (i = 0; i < totalEstudantes - 1; i++) {
        for (j = 0; j < totalEstudantes - 1 - i; j++) {
            if (lista[j].matricula > lista[j + 1].matricula) {
                temp        = lista[j];
                lista[j]    = lista[j + 1];
                lista[j + 1] = temp;
            }
        }
    }
    listaOrdenada = 1; /* lista agora esta ordenada por matricula */
    printf("\n  [OK] Lista ordenada por Matricula (Bubble Sort).\n");
}

/*
 * SELECTION SORT — Ordena por Nome (ordem alfabetica crescente)
 * Complexidade: O(n^2)
 * Ideia: encontra o menor elemento e coloca-o na posicao correcta.
 */
void selectionSortNome(void) {
    int i, j, minIdx;
    Estudante temp;

    for (i = 0; i < totalEstudantes - 1; i++) {
        minIdx = i;
        for (j = i + 1; j < totalEstudantes; j++) {
            if (strcmp(lista[j].nome, lista[minIdx].nome) < 0) {
                minIdx = j;
            }
        }
        if (minIdx != i) {
            temp         = lista[i];
            lista[i]     = lista[minIdx];
            lista[minIdx] = temp;
        }
    }
    listaOrdenada = 0; /* ja nao esta ordenada por matricula */
    printf("\n  [OK] Lista ordenada por Nome (Selection Sort).\n");
}

/*
 * INSERTION SORT — Ordena por Nota (decrescente)
 * Complexidade: O(n^2)
 * Ideia: insere cada elemento na posicao correcta da parte ja ordenada.
 */
void insertionSortNota(void) {
    int i, j;
    Estudante chave;

    for (i = 1; i < totalEstudantes; i++) {
        chave = lista[i];
        j = i - 1;
        /* Decrescente: move elementos menores para a frente */
        while (j >= 0 && lista[j].nota < chave.nota) {
            lista[j + 1] = lista[j];
            j--;
        }
        lista[j + 1] = chave;
    }
    listaOrdenada = 0;
    printf("\n  [OK] Lista ordenada por Nota (Insertion Sort).\n");
}

/* Menu de escolha de ordenacao */
void menuOrdenacao(void) {
    int opcao;

    if (totalEstudantes == 0) {
        printf("\n  [!] Nenhum estudante em memoria. Carregue os dados primeiro.\n");
        return;
    }

    printf("\n  === ORDENACAO ===\n");
    printf("  1. Por Matricula  (crescente)   — Bubble Sort\n");
    printf("  2. Por Nome       (alfabetico)  — Selection Sort\n");
    printf("  3. Por Nota       (decrescente) — Insertion Sort\n");
    printf("  0. Voltar\n");
    printf("  Opcao: ");
    scanf("%d", &opcao);

    switch (opcao) {
        case 1: bubbleSortMatricula(); break;
        case 2: selectionSortNome();   break;
        case 3: insertionSortNota();   break;
        case 0: break;
        default: printf("\n  [!] Opcao invalida.\n");
    }
}



int pesquisaLinearMatricula(int matricula) {
    int i;
    for (i = 0; i < totalEstudantes; i++) {
        if (lista[i].matricula == matricula)
            return i;
    }
    return -1;
}


int pesquisaBinariaMatricula(int matricula) {
    int inicio = 0, fim = totalEstudantes - 1, meio;

    while (inicio <= fim) {
        meio = (inicio + fim) / 2;

        if (lista[meio].matricula == matricula)
            return meio;
        else if (lista[meio].matricula < matricula)
            inicio = meio + 1;
        else
            fim = meio - 1;
    }
    return -1;
}


int pesquisaLinearNome(char *nome) {
    int i;
    for (i = 0; i < totalEstudantes; i++) {
        if (strcmp(lista[i].nome, nome) == 0)
            return i;
    }
    return -1;
}

/* Menu de pesquisa */
void menuPesquisa(void) {
    int opcao, matricula, idx;
    char nome[MAX_NOME];

    if (totalEstudantes == 0) {
        printf("\n  [!] Nenhum estudante em memoria. Carregue os dados primeiro.\n");
        return;
    }

    printf("\n  === PESQUISA ===\n");
    printf("  1. Pesquisa por Matricula (Linear)\n");
    printf("  2. Pesquisa por Matricula (Binaria — lista deve estar ordenada por matricula)\n");
    printf("  3. Pesquisa por Nome      (Linear)\n");
    printf("  0. Voltar\n");
    printf("  Opcao: ");
    scanf("%d", &opcao);

    switch (opcao) {

        case 1:
            printf("  Insira o numero de matricula: ");
            scanf("%d", &matricula);
            idx = pesquisaLinearMatricula(matricula);
            if (idx >= 0) {
                printf("\n  [OK] Estudante encontrado (Pesquisa Linear):\n");
                exibirEstudante(lista[idx]);
            } else {
                printf("\n  [!] Estudante com matricula %d nao encontrado.\n", matricula);
            }
            break;

        case 2:
            if (!listaOrdenada) {
                printf("\n  [AVISO] A lista nao esta ordenada por matricula.\n");
                printf("          Use a opcao de ordenacao (Bubble Sort) primeiro.\n");
                printf("          Deseja ordenar agora? (1=Sim / 0=Nao): ");
                scanf("%d", &opcao);
                if (opcao == 1) bubbleSortMatricula();
                else break;
            }
            printf("  Insira o numero de matricula: ");
            scanf("%d", &matricula);
            idx = pesquisaBinariaMatricula(matricula);
            if (idx >= 0) {
                printf("\n  [OK] Estudante encontrado (Pesquisa Binaria):\n");
                exibirEstudante(lista[idx]);
            } else {
                printf("\n  [!] Estudante com matricula %d nao encontrado.\n", matricula);
            }
            break;

        case 3:
            printf("  Insira o nome do estudante (sem espacos, ex: Joao_Silva): ");
            scanf("%s", nome);
            idx = pesquisaLinearNome(nome);
            if (idx >= 0) {
                printf("\n  [OK] Estudante encontrado (Pesquisa Linear por Nome):\n");
                exibirEstudante(lista[idx]);
            } else {
                printf("\n  [!] Estudante '%s' nao encontrado.\n", nome);
            }
            break;

        case 0:
            break;

        default:
            printf("\n  [!] Opcao invalida.\n");
    }
}


/* ============================================================
   MENU PRINCIPAL
   ============================================================ */

void menuPrincipal(void) {
    int opcao, sub;

    do {
        printf("\n");
        printf("    SISTEMA DE GESTAO DE ESTUDANTES       \n \n");
   
        printf("    1. Ler dados (ficheiro texto)           \n");
        printf("    2. Ler dados (ficheiro binario)         \n");
        printf("    3. Exibir lista de estudantes           \n");
        printf("    4. Ordenar estudantes                   \n");
        printf("    5. Pesquisar estudante                  \n");
        printf("    6. Gravar dados                         \n");
        printf("    0. Sair                                 \n\n");
        printf("  Opcao: ");
        scanf("%d", &opcao);

        switch (opcao) {

            case 1:
                lerFicheiroTexto();
                break;

            case 2:
                lerFicheiroBinario();
                break;

            case 3:
                exibirLista();
                break;

            case 4:
                menuOrdenacao();
                break;

            case 5:
                menuPesquisa();
                break;

            case 6:
                printf("\n  === GRAVAR DADOS ===\n");
                printf("  1. Gravar em ficheiro de texto  (%s)\n", SAIDA_TXT);
                printf("  2. Gravar em ficheiro binario   (%s)\n", FICHEIRO_BIN);
                printf("  0. Voltar\n");
                printf("  Opcao: ");
                scanf("%d", &sub);
                if      (sub == 1) gravarFicheiroTexto();
                else if (sub == 2) gravarFicheiroBinario();
                break;

            case 0:
                printf("\n  Ate breve!\n\n");
                break;

            default:
                printf("\n  [!] Opcao invalida. Tente novamente.\n");
        }

    } while (opcao != 0);
}


/* ============================================================
   FUNCAO PRINCIPAL
   ============================================================ */

int main(void) {
    printf("\n  Bem-vindo ao Sistema de Gestao de Estudantes!\n");

    menuPrincipal();

    return 0;
}
